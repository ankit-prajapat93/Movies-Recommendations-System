package com.movierecommendation.movierecommendationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRecommendationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
