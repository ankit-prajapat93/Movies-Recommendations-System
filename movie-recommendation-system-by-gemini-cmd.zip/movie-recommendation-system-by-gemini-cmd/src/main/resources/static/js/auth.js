// js/auth.js

const API_BASE_URL = 'http://localhost:8383/api'; // Adjust if your backend runs on a different port

function getToken() {
    return localStorage.getItem('jwtToken');
}

function setToken(token) {
    localStorage.setItem('jwtToken', token);
}

function removeToken() {
    localStorage.removeItem('jwtToken');
}

function getUserRole() {
    return localStorage.getItem('userRole');
}

function setUserRole(role) {
    localStorage.setItem('userRole', role);
}

function removeUserRole() {
    localStorage.removeItem('userRole');
}

function getUsername() {
    return localStorage.getItem('username');
}

function setUsername(username) {
    localStorage.setItem('username', username);
}

function removeUsername() {
    localStorage.removeItem('username');
}

function getUserId() {
    return localStorage.getItem('userId');
}

function setUserId(id) {
    localStorage.setItem('userId', id);
}

function removeUserId() {
    localStorage.removeItem('userId');
}

function isLoggedIn() {
    return getToken() !== null;
}

function updateNavbar() {
    const loginLink = document.getElementById('loginLink');
    const dashboardLink = document.getElementById('dashboardLink');
    const adminLink = document.getElementById('adminLink');
    const logoutButton = document.getElementById('logoutButton');

    if (isLoggedIn()) {
        if (loginLink) loginLink.style.display = 'none';
        if (dashboardLink) dashboardLink.style.display = 'block';
        if (logoutButton) logoutButton.style.display = 'block';

        const role = getUserRole();
        if (adminLink) {
            if (role === 'ADMIN') {
                adminLink.style.display = 'block';
            } else {
                adminLink.style.display = 'none';
            }
        }
    } else {
        if (loginLink) loginLink.style.display = 'block';
        if (dashboardLink) dashboardLink.style.display = 'none';
        if (adminLink) adminLink.style.display = 'none';
        if (logoutButton) logoutButton.style.display = 'none';
    }
}

function logout() {
    removeToken();
    removeUserRole();
    removeUsername();
    removeUserId();
    updateNavbar();
    window.location.href = '/login.html'; // Redirect to login page after logout
}

// Attach logout function to button if it exists
document.addEventListener('DOMContentLoaded', () => {
    updateNavbar();
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', logout);
    }
});
