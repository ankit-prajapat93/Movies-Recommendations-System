// js/main.js

document.addEventListener('DOMContentLoaded', () => {
    fetchMovies();

    const searchButton = document.getElementById('searchButton');
    if (searchButton) {
        searchButton.addEventListener('click', fetchMovies);
    }

    const movieSearchInput = document.getElementById('movieSearchInput');
    if (movieSearchInput) {
        movieSearchInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                fetchMovies();
            }
        });
    }
});

async function fetchMovies() {
    const moviesContainer = document.getElementById('moviesContainer');
    if (!moviesContainer) return;

    moviesContainer.innerHTML = 'Loading movies...';
    const query = document.getElementById('movieSearchInput')?.value || '';
    let url = `${API_BASE_URL}/movies`;
    if (query) {
        url = `${API_BASE_URL}/movies/search?query=${encodeURIComponent(query)}`;
    }

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const movies = await response.json();
        displayMovies(movies);
    } catch (error) {
        console.error('Error fetching movies:', error);
        moviesContainer.innerHTML = '<p>Failed to load movies. Please try again later.</p>';
    }
}

function displayMovies(movies) {
    const moviesContainer = document.getElementById('moviesContainer');
    if (!moviesContainer) return;

    moviesContainer.innerHTML = ''; // Clear previous movies

    if (movies.length === 0) {
        moviesContainer.innerHTML = '<p>No movies found.</p>';
        return;
    }

    movies.forEach(movie => {
        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';
        // Ensure genres is an array before joining
        const genres = Array.isArray(movie.genres) ? movie.genres.join(', ') : 'Unknown';
        movieCard.innerHTML = `
            <a href="/movie_detail.html?id=${movie.id}">
                <img src="${movie.posterUrl || 'https://via.placeholder.com/200x300?text=No+Poster'}" alt="${movie.title} Poster">
                <div class="movie-card-info">
                    <h3>${movie.title}</h3>
                    <p>${movie.releaseYear || 'Unknown Year'}</p>
                    <p>${genres}</p>
                </div>
            </a>
        `;
        moviesContainer.appendChild(movieCard);
    });
}
