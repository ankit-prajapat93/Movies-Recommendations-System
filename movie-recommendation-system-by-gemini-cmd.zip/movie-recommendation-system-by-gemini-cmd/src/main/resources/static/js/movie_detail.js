// js/movie_detail.js

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const movieId = urlParams.get('id');

    if (movieId) {
        fetchMovieDetail(movieId);
        if (isLoggedIn()) {
            document.getElementById('user-interaction').style.display = 'block';
            document.getElementById('loginPrompt').style.display = 'none';
            setupRatingReviewListeners(movieId);
        } else {
            document.getElementById('user-interaction').style.display = 'none';
            document.getElementById('loginPrompt').style.display = 'block';
        }
    } else {
        document.getElementById('movie-detail-main').innerHTML = '<p>Movie ID not found in URL.</p>';
    }
});

async function fetchMovieDetail(movieId) {
    try {
        const response = await fetch(`${API_BASE_URL}/movies/${movieId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const movie = await response.json();
        displayMovieDetail(movie);
        fetchMovieReviews(movieId); // Fetch reviews after movie details are loaded
    } catch (error) {
        console.error('Error fetching movie details:', error);
        document.getElementById('movie-detail-main').innerHTML = '<p>Failed to load movie details.</p>';
    }
}

function displayMovieDetail(movie) {
    document.getElementById('movieDetailTitle').textContent = movie.title;
    document.getElementById('detailTitle').textContent = movie.title;
    document.getElementById('detailReleaseYear').textContent = movie.releaseYear;
    document.getElementById('detailGenres').textContent = movie.genres.join(', ');
    document.getElementById('detailSynopsis').textContent = movie.synopsis;
    document.getElementById('detailPoster').src = movie.posterUrl || 'https://via.placeholder.com/300x450?text=No+Poster';

    if (movie.trailerUrl) {
        const trailerSection = document.getElementById('trailer-section');
        const detailTrailer = document.getElementById('detailTrailer');
        trailerSection.style.display = 'block';
        // Extract YouTube video ID from URL
        const youtubeIdMatch = movie.trailerUrl.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(.+)/);
        if (youtubeIdMatch && youtubeIdMatch[1]) {
            detailTrailer.src = `https://www.youtube.com/embed/${youtubeIdMatch[1]}`;
        } else {
            detailTrailer.src = ''; // Clear if not a valid YouTube URL
            trailerSection.style.display = 'none';
        }
    }
    // TODO: Fetch and display average rating
}

async function fetchMovieReviews(movieId) {
    const reviewsContainer = document.getElementById('reviewsContainer');
    if (!reviewsContainer) return;

    reviewsContainer.innerHTML = 'Loading reviews...';

    try {
        const response = await fetch(`${API_BASE_URL}/reviews/movies/${movieId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const reviews = await response.json();
        displayReviews(reviews);
    } catch (error) {
        console.error('Error fetching movie reviews:', error);
        reviewsContainer.innerHTML = '<p>Failed to load reviews.</p>';
    }
}

function displayReviews(reviews) {
    const reviewsContainer = document.getElementById('reviewsContainer');
    if (!reviewsContainer) return;

    reviewsContainer.innerHTML = '';
    if (reviews.length === 0) {
        reviewsContainer.innerHTML = '<p>No reviews yet. Be the first to review!</p>';
        return;
    }

    reviews.forEach(review => {
        const reviewElement = document.createElement('div');
        reviewElement.className = 'review-item';
        reviewElement.innerHTML = `
            <strong>${review.username}</strong> on ${new Date(review.createdAt).toLocaleDateString()}:
            <p>${review.reviewText}</p>
        `;
        reviewsContainer.appendChild(reviewElement);
    });
}

function setupRatingReviewListeners(movieId) {
    const submitRatingButton = document.getElementById('submitRating');
    const submitReviewButton = document.getElementById('submitReview');
    const interactionMessage = document.getElementById('interactionMessage');

    if (submitRatingButton) {
        submitRatingButton.addEventListener('click', async () => {
            interactionMessage.textContent = '';
            const ratingValue = document.getElementById('userRating').value;
            if (!ratingValue) {
                interactionMessage.textContent = 'Please select a rating.';
                interactionMessage.style.color = 'red';
                return;
            }
            try {
                const response = await fetch(`${API_BASE_URL}/ratings/movies/${movieId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${getToken()}`
                    },
                    body: JSON.stringify({ rating: parseInt(ratingValue) })
                });
                if (!response.ok) {
                    const errorData = await response.text();
                    throw new Error(errorData || `HTTP error! status: ${response.status}`);
                }
                interactionMessage.textContent = 'Rating submitted successfully!';
                interactionMessage.style.color = 'green';
                // Optionally refresh movie details to show updated average rating
            } catch (error) {
                console.error('Error submitting rating:', error);
                interactionMessage.textContent = `Failed to submit rating: ${error.message}`;
                interactionMessage.style.color = 'red';
            }
        });
    }

    if (submitReviewButton) {
        submitReviewButton.addEventListener('click', async () => {
            interactionMessage.textContent = '';
            const reviewText = document.getElementById('userReview').value;
            if (!reviewText.trim()) {
                interactionMessage.textContent = 'Review cannot be empty.';
                interactionMessage.style.color = 'red';
                return;
            }
            try {
                const response = await fetch(`${API_BASE_URL}/reviews/movies/${movieId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${getToken()}`
                    },
                    body: JSON.stringify({ reviewText })
                });
                if (!response.ok) {
                    const errorData = await response.text();
                    throw new Error(errorData || `HTTP error! status: ${response.status}`);
                }
                interactionMessage.textContent = 'Review submitted successfully!';
                interactionMessage.style.color = 'green';
                document.getElementById('userReview').value = ''; // Clear review box
                fetchMovieReviews(movieId); // Refresh reviews list
            } catch (error) {
                console.error('Error submitting review:', error);
                interactionMessage.textContent = `Failed to submit review: ${error.message}`;
                interactionMessage.style.color = 'red';
            }
        });
    }
}
