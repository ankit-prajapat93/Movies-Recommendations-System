// js/admin.js

document.addEventListener('DOMContentLoaded', () => {
    if (!isLoggedIn() || getUserRole() !== 'ADMIN') {
        window.location.href = '/'; // Redirect if not admin
        return;
    }

    fetchAdminMovies();
    fetchAdminUsers();
    fetchAdminReviews();

    const showAddMovieFormButton = document.getElementById('showAddMovieFormButton');
    const addMovieFormContainer = document.getElementById('addMovieFormContainer');
    const movieForm = document.getElementById('movieForm');
    const cancelMovieFormButton = document.getElementById('cancelMovieFormButton');

    if (showAddMovieFormButton) {
        showAddMovieFormButton.addEventListener('click', () => {
            addMovieFormContainer.style.display = 'block';
            movieForm.reset();
            document.getElementById('movieId').value = ''; // Clear hidden ID for new movie
        });
    }

    if (cancelMovieFormButton) {
        cancelMovieFormButton.addEventListener('click', () => {
            addMovieFormContainer.style.display = 'none';
        });
    }

    if (movieForm) {
        movieForm.addEventListener('submit', handleMovieFormSubmit);
    }
});

async function fetchAdminMovies() {
    const adminMoviesList = document.getElementById('adminMoviesList');
    if (!adminMoviesList) return;

    adminMoviesList.innerHTML = 'Loading movies...';

    try {
        const response = await fetch(`${API_BASE_URL}/movies`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const movies = await response.json();
        displayAdminMovies(movies);
    } catch (error) {
        console.error('Error fetching admin movies:', error);
        adminMoviesList.innerHTML = '<p>Failed to load movies.</p>';
    }
}

function displayAdminMovies(movies) {
    const adminMoviesList = document.getElementById('adminMoviesList');
    if (!adminMoviesList) return;

    adminMoviesList.innerHTML = '';
    if (movies.length === 0) {
        adminMoviesList.innerHTML = '<p>No movies in the database.</p>';
        return;
    }

    movies.forEach(movie => {
        const movieItem = document.createElement('div');
        movieItem.className = 'admin-item';
        movieItem.innerHTML = `
            <div class="admin-item-info">
                <strong>${movie.title}</strong> (${movie.releaseYear}) - ${movie.genres.join(', ')}
            </div>
            <div>
                <button class="edit-button" data-id="${movie.id}">Edit</button>
                <button class="delete-button" data-id="${movie.id}">Delete</button>
            </div>
        `;
        adminMoviesList.appendChild(movieItem);
    });

    adminMoviesList.querySelectorAll('.edit-button').forEach(button => {
        button.addEventListener('click', (event) => editMovie(event.target.dataset.id));
    });
    adminMoviesList.querySelectorAll('.delete-button').forEach(button => {
        button.addEventListener('click', (event) => deleteMovie(event.target.dataset.id));
    });
}

async function editMovie(id) {
    const addMovieFormContainer = document.getElementById('addMovieFormContainer');
    const movieFormMessage = document.getElementById('movieFormMessage');
    movieFormMessage.textContent = '';

    try {
        const response = await fetch(`${API_BASE_URL}/movies/${id}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const movie = await response.json();

        document.getElementById('movieId').value = movie.id;
        document.getElementById('movieTitle').value = movie.title;
        document.getElementById('movieSynopsis').value = movie.synopsis; // Corrected from movie.synopsi
        document.getElementById('movieReleaseYear').value = movie.releaseYear;
        document.getElementById('moviePosterUrl').value = movie.posterUrl;
        document.getElementById('movieTrailerUrl').value = movie.trailerUrl;
        document.getElementById('movieGenres').value = movie.genres.join(', ');

        addMovieFormContainer.style.display = 'block';
    } catch (error) {
        console.error('Error fetching movie for edit:', error);
        movieFormMessage.textContent = 'Failed to load movie for editing.';
    }
}

async function handleMovieFormSubmit(event) {
    event.preventDefault();
    const movieFormMessage = document.getElementById('movieFormMessage');
    movieFormMessage.textContent = '';

    const movieId = document.getElementById('movieId').value;
    const title = document.getElementById('movieTitle').value;
    const synopsis = document.getElementById('movieSynopsis').value;
    const releaseYear = document.getElementById('movieReleaseYear').value;
    const posterUrl = document.getElementById('moviePosterUrl').value;
    const trailerUrl = document.getElementById('movieTrailerUrl').value;
    const genreNames = document.getElementById('movieGenres').value.split(',').map(g => g.trim()).filter(g => g);

    const movieData = { title, synopsis, releaseYear: parseInt(releaseYear), posterUrl, trailerUrl, genreNames };

    try {
        const method = movieId ? 'PUT' : 'POST';
        const url = movieId ? `${API_BASE_URL}/movies/${movieId}` : `${API_BASE_URL}/movies`;

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            },
            body: JSON.stringify(movieData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
        }

        movieFormMessage.textContent = `Movie ${movieId ? 'updated' : 'added'} successfully!`;
        movieFormMessage.style.color = 'green';
        document.getElementById('addMovieFormContainer').style.display = 'none';
        fetchAdminMovies(); // Refresh list
    } catch (error) {
        console.error('Error saving movie:', error);
        movieFormMessage.textContent = `Failed to save movie: ${error.message}`;
        movieFormMessage.style.color = 'red';
    }
}

async function deleteMovie(id) {
    if (!confirm('Are you sure you want to delete this movie?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/movies/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        alert('Movie deleted successfully!');
        fetchAdminMovies(); // Refresh list
    } catch (error) {
        console.error('Error deleting movie:', error);
        alert('Failed to delete movie.');
    }
}

async function fetchAdminUsers() {
    const adminUsersList = document.getElementById('adminUsersList');
    if (!adminUsersList) return;

    adminUsersList.innerHTML = 'Loading users...';

    try {
        const response = await fetch(`${API_BASE_URL}/admin/users`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const users = await response.json();
        displayAdminUsers(users);
    } catch (error) {
        console.error('Error fetching admin users:', error);
        adminUsersList.innerHTML = '<p>Failed to load users.</p>';
    }
}

function displayAdminUsers(users) {
    const adminUsersList = document.getElementById('adminUsersList');
    if (!adminUsersList) return;

    adminUsersList.innerHTML = '';
    if (users.length === 0) {
        adminUsersList.innerHTML = '<p>No users in the database.</p>';
        return;
    }

    users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.className = 'admin-item';
        userItem.innerHTML = `
            <div class="admin-item-info">
                <strong>${user.username}</strong> (${user.email}) - Role: ${user.role}
            </div>
            <div>
                ${user.role !== 'ADMIN' ? `<button class="ban-button" data-id="${user.id}">Ban</button>` : ''}
                <button class="delete-button" data-id="${user.id}">Delete</button>
            </div>
        `;
        adminUsersList.appendChild(userItem);
    });

    adminUsersList.querySelectorAll('.ban-button').forEach(button => {
        button.addEventListener('click', (event) => banUser(event.target.dataset.id));
    });
    adminUsersList.querySelectorAll('.delete-button').forEach(button => {
        button.addEventListener('click', (event) => deleteUser(event.target.dataset.id));
    });
}

async function banUser(id) {
    if (!confirm('Are you sure you want to ban this user?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/admin/users/${id}/ban`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        alert('User banned successfully!');
        fetchAdminUsers(); // Refresh list
    } catch (error) {
        console.error('Error banning user:', error);
        alert('Failed to ban user.');
    }
}

async function deleteUser(id) {
    if (!confirm('Are you sure you want to delete this user?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/admin/users/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        alert('User deleted successfully!');
        fetchAdminUsers(); // Refresh list
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('Failed to delete user.');
    }
}

async function fetchAdminReviews() {
    const adminReviewsList = document.getElementById('adminReviewsList');
    if (!adminReviewsList) return;

    adminReviewsList.innerHTML = 'Loading reviews...';

    try {
        const response = await fetch(`${API_BASE_URL}/admin/reviews`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const reviews = await response.json();
        displayAdminReviews(reviews);
    } catch (error) {
        console.error('Error fetching admin reviews:', error);
        adminReviewsList.innerHTML = '<p>Failed to load reviews.</p>';
    }
}

function displayAdminReviews(reviews) {
    const adminReviewsList = document.getElementById('adminReviewsList');
    if (!adminReviewsList) return;

    adminReviewsList.innerHTML = '';
    if (reviews.length === 0) {
        adminReviewsList.innerHTML = '<p>No reviews to moderate.</p>';
        return;
    }

    reviews.forEach(review => {
        const reviewItem = document.createElement('div');
        reviewItem.className = 'admin-item';
        reviewItem.innerHTML = `
            <div class="admin-item-info">
                <strong>Movie:</strong> ${review.movieTitle}<br>
                <strong>User:</strong> ${review.username}<br>
                <strong>Review:</strong> ${review.reviewText}
            </div>
            <div>
                <button class="delete-button" data-id="${review.id}">Delete</button>
            </div>
        `;
        adminReviewsList.appendChild(reviewItem);
    });

    adminReviewsList.querySelectorAll('.delete-button').forEach(button => {
        button.addEventListener('click', (event) => deleteReview(event.target.dataset.id));
    });
}

async function deleteReview(id) {
    if (!confirm('Are you sure you want to delete this review?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/admin/reviews/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        alert('Review deleted successfully!');
        fetchAdminReviews(); // Refresh list
    } catch (error) {
        console.error('Error deleting review:', error);
        alert('Failed to delete review.');
    }
}
