// js/login.js

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const loginMessage = document.getElementById('loginMessage');
    const registerMessage = document.getElementById('registerMessage');

    if (isLoggedIn()) {
        window.location.href = '/'; // Redirect to home if already logged in
        return;
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            loginMessage.textContent = '';

            const username = loginForm.loginUsername.value;
            const password = loginForm.loginPassword.value;

            try {
                const response = await fetch(`${API_BASE_URL}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();

                if (response.ok) {
                    setToken(data.token);
                    setUserId(data.id);
                    setUsername(data.username);
                    setUserRole(data.role);
                    window.location.href = '/'; // Redirect to home page
                } else {
                    loginMessage.textContent = data.message || 'Login failed. Please check your credentials.';
                }
            } catch (error) {
                console.error('Error during login:', error);
                loginMessage.textContent = 'An error occurred. Please try again.';
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            registerMessage.textContent = '';

            const username = registerForm.registerUsername.value;
            const email = registerForm.registerEmail.value;
            const password = registerForm.registerPassword.value;

            try {
                const response = await fetch(`${API_BASE_URL}/auth/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, email, password })
                });

                const data = await response.text(); // Assuming text response for success/failure

                if (response.ok) {
                    registerMessage.textContent = 'Registration successful! You can now log in.';
                    registerMessage.style.color = 'green';
                    registerForm.reset();
                } else {
                    registerMessage.textContent = data || 'Registration failed. Please try again.';
                    registerMessage.style.color = 'red';
                }
            } catch (error) {
                console.error('Error during registration:', error);
                registerMessage.textContent = 'An error occurred. Please try again.';
                registerMessage.style.color = 'red';
            }
        });
    }
});
