// js/dashboard.js

document.addEventListener('DOMContentLoaded', () => {
    if (!isLoggedIn()) {
        window.location.href = '/login.html'; // Redirect to login if not authenticated
        return;
    }

    displayUserInfo();
    fetchRecommendations();
    fetchMyRatings();
});

function displayUserInfo() {
    const usernameSpan = document.getElementById('dashboardUsername');
    const emailSpan = document.getElementById('dashboardEmail');

    if (usernameSpan) usernameSpan.textContent = getUsername();
    // Email is not stored in localStorage in current auth.js, would need to be added
    // if (emailSpan) emailSpan.textContent = getUserEmail();
}

async function fetchRecommendations() {
    const recommendationsContainer = document.getElementById('recommendationsContainer');
    if (!recommendationsContainer) return;

    recommendationsContainer.innerHTML = 'Loading recommendations...';

    try {
        const response = await fetch(`${API_BASE_URL}/recommendations`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const movies = await response.json();
        displayMovies(movies, recommendationsContainer);
    } catch (error) {
        console.error('Error fetching recommendations:', error);
        recommendationsContainer.innerHTML = '<p>Failed to load recommendations. Please try again later.</p>';
    }
}

async function fetchMyRatings() {
    const myRatingsContainer = document.getElementById('myRatingsContainer');
    if (!myRatingsContainer) return;

    myRatingsContainer.innerHTML = 'Loading your rated movies...';

    try {
        const response = await fetch(`${API_BASE_URL}/ratings/my-ratings`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const ratings = await response.json();
        // Extract movies from ratings and display them
        const movies = ratings.map(rating => ({
            id: rating.movieId,
            title: rating.movieTitle,
            // Assuming we don't have posterUrl or releaseYear directly from rating DTO
            // For a full implementation, you might fetch movie details or include them in RatingDto
            posterUrl: 'https://via.placeholder.com/200x300?text=Rated+Movie', // Placeholder
            releaseYear: 'N/A',
            genres: []
        }));
        displayMovies(movies, myRatingsContainer);
    } catch (error) {
        console.error('Error fetching my ratings:', error);
        myRatingsContainer.innerHTML = '<p>Failed to load your rated movies. Please try again later.</p>';
    }
}

function displayMovies(movies, container) {
    container.innerHTML = ''; // Clear previous content

    if (movies.length === 0) {
        container.innerHTML = '<p>No movies to display.</p>';
        return;
    }

    movies.forEach(movie => {
        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';
        movieCard.innerHTML = `
            <a href="/movie_detail.html?id=${movie.id}">
                <img src="${movie.posterUrl || 'https://via.placeholder.com/200x300?text=No+Poster'}" alt="${movie.title} Poster">
                <div class="movie-card-info">
                    <h3>${movie.title}</h3>
                    <p>${movie.releaseYear}</p>
                    ${movie.genres && movie.genres.length > 0 ? `<p>${movie.genres.join(', ')}</p>` : ''}
                </div>
            </a>
        `;
        container.appendChild(movieCard);
    });
}
