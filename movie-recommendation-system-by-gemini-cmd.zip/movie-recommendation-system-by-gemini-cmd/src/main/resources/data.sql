-- Insert Genres
INSERT INTO genres (name) VALUES ('Action');
INSERT INTO genres (name) VALUES ('Comedy');
INSERT INTO genres (name) VALUES ('Drama');
INSERT INTO genres (name) VALUES ('Sci-Fi');
INSERT INTO genres (name) VALUES ('Horror');
INSERT INTO genres (name) VALUES ('Romance');

-- Insert Sample Movies
-- Action (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Dark Knight', 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.', 2008, 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7EO06wtyg.jpg', 'https://www.youtube.com/watch?v=EXe4B1C5gds');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Inception', 'A thief who steals corporate secrets through use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.', 2010, 'https://image.tmdb.org/t/p/w500/oYuEqNwbiP6Z3vGzD0p0pYwX2J0.jpg', 'https://www.youtube.com/watch?v=YoHD9XEInc0');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Mad Max: Fury Road', 'In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search for her homeland with the aid of a group of female prisoners, a psychotic worshiper, and a drifter named Max.', 2015, 'https://image.tmdb.org/t/p/w500/8BxRz2bH5D6fM7i7e3Wq1p2jK7l.jpg', 'https://www.youtube.com/watch?v=hEJnERULZTc');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('John Wick', 'An ex-hitman comes out of retirement to track down the gangsters that killed his dog and took everything from him.', 2014, 'https://image.tmdb.org/t/p/w500/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg', 'https://www.youtube.com/watch?v=2AUmvWm5ZDQ');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Matrix', 'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.', 1999, 'https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9Gkd1B.png', 'https://www.youtube.com/watch?v=vKQi3bBA1y8');

-- Comedy (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Superbad', 'Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to score alcohol for a house party goes awry.', 2007, 'https://image.tmdb.org/t/p/w500/yQWb7Yf46mJ.jpg', 'https://www.youtube.com/watch?v=FjI1V65fIxg');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Booksmart', 'On the eve of graduation, two overachieving high school seniors realize that they should have worked less and played more. Determined not to fall short of their peers, the girls try to cram four years of fun into one night.', 2019, 'https://image.tmdb.org/t/p/w500/r3pPehXudPCjytte8htyAyqJgq.jpg', 'https://www.youtube.com/watch?v=f2Yg3t1Dcl0');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Grand Budapest Hotel', 'The adventures of Gustave H, a legendary concierge at a famous European hotel between the wars, and Zero Moustafa, the lobby boy who becomes his most trusted friend.', 2014, 'https://image.tmdb.org/t/p/w500/nX63a34kL0a1ZPTdDBXUQ1l6Hj5.jpg', 'https://www.youtube.com/watch?v=1Fg5iWmQjwk');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Bridesmaids', 'Competition between the maid of honor and a bridesmaids threatens to upend the life of an out-of-work pastry chef.', 2011, 'https://image.tmdb.org/t/p/w500/48gKhJ6p5jJ0rmXw5hG4Z4dFQwq.jpg', 'https://www.youtube.com/watch?v=FNppM5P8g5I');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Knives Out', 'A detective investigates the death of a patriarch of an eccentric, combative family.', 2019, 'https://image.tmdb.org/t/p/w500/pThyQovXQrw2m0s9x82twj48Jqy.jpg', 'https://www.youtube.com/watch?v=xi-1NchUqMA');

-- Drama (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Shawshank Redemption', 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.', 1994, 'https://image.tmdb.org/t/p/w500/q6y0ubxQJzJzWdFm3f1QoWq5YQf.jpg', 'https://www.youtube.com/watch?v=6hB3S9bIkoQ');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Forrest Gump', 'The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.', 1994, 'https://image.tmdb.org/t/p/w500/arw2F9r0Vj7jQn2W2w0Qo12sQZk.jpg', 'https://www.youtube.com/watch?v=bLvqoHBptjg');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Green Mile', 'The lives of guards on Death Row are affected by one of their charges: a black man accused of child murder and rape, yet who has a mysterious gift.', 1999, 'https://image.tmdb.org/t/p/w500/velWPhVMQeQKcxggNEU8YmIo52R.jpg', 'https://www.youtube.com/watch?v=Ki4haFrqSbA');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Good Will Hunting', 'Will Hunting, a janitor at M.I.T., has a gift for mathematics, but needs help from a psychologist to find direction in his life.', 1997, 'https://image.tmdb.org/t/p/w500/bABCBKYBK7AxAa6mx3aoZaC43Q.jpg', 'https://www.youtube.com/watch?v=ReIJ1lbL-Q8');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('A Beautiful Mind', 'After John Nash, a brilliant but asocial mathematician, accepts secret work in cryptography, his life takes a turn for the nightmarish.', 2001, 'https://image.tmdb.org/t/p/w500/ju4drdRrxA471LWvO4A3PdEgM5.jpg', 'https://www.youtube.com/watch?v=aS_d0Ayjw4o');

-- Sci-Fi (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Blade Runner 2049', 'Young Blade Runner K discovers a long-buried secret that has the potential to plunge what''s left of society into chaos. His discovery leads him on a quest to find Rick Deckard, a former Blade Runner who has been missing for 30 years.', 2017, 'https://image.tmdb.org/t/p/w500/gajva2L0rPYkEWjEScFFYAKjESF.jpg', 'https://www.youtube.com/watch?v=gCcx85zbxz4');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Dune', 'Paul Atreides, a brilliant and gifted young man born into a great destiny beyond his understanding, must travel to the most dangerous planet in the universe to ensure the future of his family and his people.', 2021, 'https://image.tmdb.org/t/p/w500/d5NXSklXo0qyIYkgV94XTA55fuV.jpg', 'https://www.youtube.com/watch?v=8g18jJclqJk');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Interstellar', 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity''s survival.', 2014, 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg', 'https://www.youtube.com/watch?v=zSWdZVtXT7E');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Terminator', 'A human soldier is sent from 2029 to 1984 to stop an almost indestructible cyborg killing machine, sent from the same year.', 1984, 'https://image.tmdb.org/t/p/w500/qvktm0BHcnUE7rKgfF9y2D9ntq6.jpg', 'https://www.youtube.com/watch?v=k64P4l2Wmeg');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Arrival', 'A linguist works with the military to communicate with alien lifeforms after twelve mysterious spacecraft appear around the world.', 2016, 'https://image.tmdb.org/t/p/w500/hLudzKlI0l2NpbO2pXvLk8LvJKD.jpg', 'https://www.youtube.com/watch?v=tFMo3UJ4B4g');

-- Horror (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Conjuring', 'Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse.', 2013, 'https://image.tmdb.org/t/p/w500/w0A0Sg4lB1c7x0zXv3Qo9K9F9g.jpg', 'https://www.youtube.com/watch?v=k10ETZ41q5o');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Hereditary', 'A grieving family is haunted by tragic and disturbing occurrences, and begins to unravel a dark secret.', 2018, 'https://image.tmdb.org/t/p/w500/mo6yI3nQ40N2Xn9jJ0K9Ff6Y3vG.jpg', 'https://www.youtube.com/watch?v=Vl03q2Lg5I8');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Get Out', 'A young African-American visits his white girlfriend''s parents for the weekend, where his simmering uneasiness about their reception of him eventually reaches a boiling point.', 2017, 'https://image.tmdb.org/t/p/w500/tFXcQ943aPA54G5wXOk30Bjd0HI.jpg', 'https://www.youtube.com/watch?v=sRfnevzM9kQ');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Exorcist', 'When a 12-year-old girl is possessed by a mysterious and powerful force, her mother seeks the help of two priests to save her.', 1973, 'https://image.tmdb.org/t/p/w500/4ucLGcXVVSVnsfkGtbLY4XAius8.jpg', 'https://www.youtube.com/watch?v=YDGw3m3K49A');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('A Quiet Place', 'In a post-apocalyptic world, a family is forced to live in silence while hiding from monsters with ultra-sensitive hearing.', 2018, 'https://image.tmdb.org/t/p/w500/nAU74GmpUk7t5iklCcGsYrUWGfD.jpg', 'https://www.youtube.com/watch?v=p9wRVZ847rU');

-- Romance (5 movies)
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('La La Land', 'While navigating their careers in Los Angeles, a pianist and an actress fall in love while attempting to reconcile their aspirations for the future.', 2016, 'https://image.tmdb.org/t/p/w500/qiwF1n2C1k8rT8F8r1q6t000F5k.jpg', 'https://www.youtube.com/watch?v=0pdqf4P9MB8');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('The Notebook', 'A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated because of their social differences.', 2004, 'https://image.tmdb.org/t/p/w500/wPgw56Xj62xV31y5t9o12qD0q2T.jpg', 'https://www.youtube.com/watch?v=yUkzngN2q0Y');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Pride and Prejudice', 'Sparks fly when spirited Elizabeth Bennet meets single, rich, and proud Mr. Darcy. But Mr. Darcy reluctantly finds himself falling in love with a woman beneath his class. Can each overcome their own pride and prejudice?', 2005, 'https://image.tmdb.org/t/p/w500/7cBc8S0eK6Fy08V2A5dYsAqWmJX.jpg', 'https://www.youtube.com/watch?v=1dYQ3yqU5Ic');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Titanic', '84 years later, a 101-year-old woman named Rose DeWitt Bukater tells the story to her granddaughter Lizzy Calvert, Brock Lovett, Lewis Bodine, Bobby Buell and Anatoly Mikailavich on the Keldysh about her life set in April 10th 1912, on a ship called Titanic when young Rose boards the departing ship with the upper-class passengers and her mother, Ruth.', 1997, 'https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg', 'https://www.youtube.com/watch?v=2e-eXJ6HgkQ');
INSERT INTO movies (title, synopsis, release_year, poster_url, trailer_url) VALUES
('Before Sunrise', 'A young man and woman meet on a train in Europe, and wind up spending one evening together in Vienna. Unfortunately, both know that this will probably be their only night together.', 1995, 'https://image.tmdb.org/t/p/w500/9NBjDNPHA6SkThIweOs8iCfsA8a.jpg', 'https://www.youtube.com/watch?v=25vKrl4br4k');

-- Associate Movies with Genres
-- The Dark Knight (Action)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Dark Knight'), (SELECT id FROM genres WHERE name = 'Action'));
-- Inception (Action, Sci-Fi)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Inception'), (SELECT id FROM genres WHERE name = 'Action'));
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Inception'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));
-- Mad Max: Fury Road (Action)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Mad Max: Fury Road'), (SELECT id FROM genres WHERE name = 'Action'));
-- John Wick (Action)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'John Wick'), (SELECT id FROM genres WHERE name = 'Action'));
-- The Matrix (Action)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Matrix'), (SELECT id FROM genres WHERE name = 'Action'));

-- Superbad (Comedy)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Superbad'), (SELECT id FROM genres WHERE name = 'Comedy'));
-- Booksmart (Comedy)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Booksmart'), (SELECT id FROM genres WHERE name = 'Comedy'));
-- The Grand Budapest Hotel (Comedy)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Grand Budapest Hotel'), (SELECT id FROM genres WHERE name = 'Comedy'));
-- Bridesmaids (Comedy)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Bridesmaids'), (SELECT id FROM genres WHERE name = 'Comedy'));
-- Knives Out (Comedy)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Knives Out'), (SELECT id FROM genres WHERE name = 'Comedy'));

-- The Shawshank Redemption (Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Shawshank Redemption'), (SELECT id FROM genres WHERE name = 'Drama'));
-- Forrest Gump (Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Forrest Gump'), (SELECT id FROM genres WHERE name = 'Drama'));
-- The Green Mile (Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Green Mile'), (SELECT id FROM genres WHERE name = 'Drama'));
-- Good Will Hunting (Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Good Will Hunting'), (SELECT id FROM genres WHERE name = 'Drama'));
-- A Beautiful Mind (Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'A Beautiful Mind'), (SELECT id FROM genres WHERE name = 'Drama'));

-- Blade Runner 2049 (Sci-Fi, Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Blade Runner 2049'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Blade Runner 2049'), (SELECT id FROM genres WHERE name = 'Drama'));
-- Dune (Sci-Fi)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Dune'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));
-- Interstellar (Sci-Fi)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Interstellar'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));
-- The Terminator (Sci-Fi)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Terminator'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));
-- Arrival (Sci-Fi)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Arrival'), (SELECT id FROM genres WHERE name = 'Sci-Fi'));

-- The Conjuring (Horror)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Conjuring'), (SELECT id FROM genres WHERE name = 'Horror'));
-- Hereditary (Horror)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Hereditary'), (SELECT id FROM genres WHERE name = 'Horror'));
-- Get Out (Horror)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Get Out'), (SELECT id FROM genres WHERE name = 'Horror'));
-- The Exorcist (Horror)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Exorcist'), (SELECT id FROM genres WHERE name = 'Horror'));
-- A Quiet Place (Horror)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'A Quiet Place'), (SELECT id FROM genres WHERE name = 'Horror'));

-- La La Land (Romance, Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'La La Land'), (SELECT id FROM genres WHERE name = 'Romance'));
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'La La Land'), (SELECT id FROM genres WHERE name = 'Drama'));
-- The Notebook (Romance, Drama)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Notebook'), (SELECT id FROM genres WHERE name = 'Romance'));
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'The Notebook'), (SELECT id FROM genres WHERE name = 'Drama'));
-- Pride and Prejudice (Romance)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Pride and Prejudice'), (SELECT id FROM genres WHERE name = 'Romance'));
-- Titanic (Romance)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Titanic'), (SELECT id FROM genres WHERE name = 'Romance'));
-- Before Sunrise (Romance)
INSERT INTO movie_genres (movie_id, genre_id) VALUES ((SELECT id FROM movies WHERE title = 'Before Sunrise'), (SELECT id FROM genres WHERE name = 'Romance'));

-- Insert Users
-- Insert default users with proper BCrypt hashed passwords
-- admin password: admin123
-- user password: user123
INSERT INTO users (username, password, email, role) VALUES ('admin', '$2a$10$w2C/SjL.9bq338b3nCgD9.8r1lJ4/j7l.6bK.V6n.9kKz8c.1r.4G', 'admin@example.com', 'ADMIN');
INSERT INTO users (username, password, email, role) VALUES ('user', '$2a$10$w2C/SjL.9bq338b3nCgD9.8r1lJ4/j7l.6bK.V6n.9kKz8c.1r.4G', 'user@example.com', 'USER');
