package com.movierecommendation.movierecommendationsystem.controller;

import com.movierecommendation.movierecommendationsystem.dto.ReviewDto;
import com.movierecommendation.movierecommendationsystem.dto.UserDto;
import com.movierecommendation.movierecommendationsystem.model.Review;
import com.movierecommendation.movierecommendationsystem.model.User;
import com.movierecommendation.movierecommendationsystem.repository.ReviewRepository;
import com.movierecommendation.movierecommendationsystem.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')") // All endpoints in this controller require ADMIN role
public class AdminController {

    private final UserRepository userRepository;
    private final ReviewRepository reviewRepository;

    public AdminController(UserRepository userRepository, ReviewRepository reviewRepository) {
        this.userRepository = userRepository;
        this.reviewRepository = reviewRepository;
    }

    // User Management
    @GetMapping("/users")
    public ResponseEntity<List<UserDto>> getAllUsers() {
        List<UserDto> users = userRepository.findAll().stream()
                .map(UserDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(users);
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/users/{id}/ban")
    public ResponseEntity<?> banUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setRole("BANNED"); // Or a more sophisticated status field
                    userRepository.save(user);
                    return ResponseEntity.ok("User " + user.getUsername() + " banned successfully.");
                })
                .orElse(new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND));
    }

    // Review Moderation
    @GetMapping("/reviews")
    public ResponseEntity<List<ReviewDto>> getAllReviews() {
        List<ReviewDto> reviews = reviewRepository.findAll().stream()
                .map(ReviewDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(reviews);
    }

    @DeleteMapping("/reviews/{id}")
    public ResponseEntity<Void> deleteReview(@PathVariable Long id) {
        if (reviewRepository.existsById(id)) {
            reviewRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // TODO: Add reporting endpoints (e.g., popular movies, user engagement)
}
