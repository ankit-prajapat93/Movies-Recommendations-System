package com.movierecommendation.movierecommendationsystem.service;

import com.movierecommendation.movierecommendationsystem.model.Genre;
import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.model.Rating;
import com.movierecommendation.movierecommendationsystem.model.User;
import com.movierecommendation.movierecommendationsystem.repository.GenreRepository;
import com.movierecommendation.movierecommendationsystem.repository.MovieRepository;
import com.movierecommendation.movierecommendationsystem.repository.RatingRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class RecommendationService {

    private final RatingRepository ratingRepository;
    private final MovieRepository movieRepository;
    private final GenreRepository genreRepository;

    public RecommendationService(RatingRepository ratingRepository, MovieRepository movieRepository, GenreRepository genreRepository) {
        this.ratingRepository = ratingRepository;
        this.movieRepository = movieRepository;
        this.genreRepository = genreRepository;
    }

    @Cacheable(value = "recommendations", key = "#user.id")
    public List<Movie> getRecommendedMovies(User user) {
        // 1. Get all movies rated by the user
        List<Rating> userRatings = ratingRepository.findByUser(user);

        if (userRatings.isEmpty()) {
            // Cold start: If user hasn't rated anything, return diverse recommendations
            // Include a mix of popular movies, recent releases, and movies from different genres
            List<Movie> popularMovies = movieRepository.findTopRatedMovies(PageRequest.of(0, 10)).getContent();
            List<Movie> recentMovies = movieRepository.findRecentMovies(java.time.Year.now().getValue() - 2, PageRequest.of(0, 5)).getContent();
            
            // Combine and shuffle to provide diversity
            List<Movie> coldStartRecommendations = new ArrayList<>();
            coldStartRecommendations.addAll(popularMovies);
            coldStartRecommendations.addAll(recentMovies);
            
            // Add some movies from different genres to ensure diversity
            List<Genre> allGenres = genreRepository.findAll();
            Collections.shuffle(allGenres);
            
            for (int i = 0; i < Math.min(5, allGenres.size()); i++) {
                List<Movie> genreMovies = movieRepository.findByGenresContaining(allGenres.get(i), PageRequest.of(0, 2)).getContent();
                coldStartRecommendations.addAll(genreMovies);
            }
            
            // Remove duplicates and limit to 20
            return coldStartRecommendations.stream()
                    .distinct()
                    .limit(20)
                    .collect(Collectors.toList());
        }

        // 2. Collect genres from all rated movies, with weights
        Map<Genre, Double> preferredGenres = userRatings.stream()
                .flatMap(rating -> rating.getMovie().getGenres().stream()
                        .map(genre -> new AbstractMap.SimpleEntry<>(genre, getRatingWeight(rating.getRating()))))
                .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.summingDouble(Map.Entry::getValue)));

        // 3. Get all movies that the user has already rated
        Set<Long> ratedMovieIds = userRatings.stream().map(r -> r.getMovie().getId()).collect(Collectors.toSet());

        // 4. Find movies that match preferred genres and haven't been rated by the user
        List<Movie> recommendedMovies = movieRepository.findTop50ByGenresInAndIdNotIn(
                preferredGenres.keySet(),
                ratedMovieIds,
                PageRequest.of(0, 50) // Reduced from 100 to 50 for better performance
        );

        // 5. Collaborative filtering: Find similar users and their movies
        Set<Movie> ratedMovies = userRatings.stream().map(Rating::getMovie).collect(Collectors.toSet());
        List<User> similarUsers = ratingRepository.findSimilarUsers(user, ratedMovies);
        Set<Long> collaborativeMovieIds = ratingRepository.findMoviesFromSimilarUsers(similarUsers, ratedMovieIds);

        // Add movies from collaborative filtering to recommendations
        recommendedMovies.addAll(movieRepository.findAllById(collaborativeMovieIds));

        // 6. Add popularity, recency, and diversity score and sort
        // Sort with diversity consideration
        List<Movie> finalRecommendations = new ArrayList<>();
        List<Movie> remainingMovies = new ArrayList<>(recommendedMovies);
        
        // Select top recommendations with diversity
        while (finalRecommendations.size() < 20 && !remainingMovies.isEmpty()) {
            Movie bestMovie = null;
            double bestScore = -1;
            
            for (Movie movie : remainingMovies) {
                double score = calculateRecommendationScore(movie, preferredGenres, finalRecommendations);
                if (score > bestScore) {
                    bestScore = score;
                    bestMovie = movie;
                }
            }
            
            if (bestMovie != null) {
                finalRecommendations.add(bestMovie);
                remainingMovies.remove(bestMovie);
            } else {
                break;
            }
        }
        
        return finalRecommendations;
    }

    private double getRatingWeight(int rating) {
        return switch (rating) {
            case 5 -> 1.5;
            case 4 -> 1.2;
            case 3 -> 1.0;
            case 2 -> 0.5;
            case 1 -> 0.2;
            default -> 0.0;
        };
    }

    private double calculateRecommendationScore(Movie movie, Map<Genre, Double> preferredGenres, List<Movie> alreadyRecommended) {
        // Genre preference score based on user's ratings
        double genreScore = movie.getGenres().stream()
                .mapToDouble(genre -> preferredGenres.getOrDefault(genre, 0.0))
                .sum();

        // Popularity score based on average rating and number of ratings
        double avgRating = movie.getRatings().stream().mapToInt(Rating::getRating).average().orElse(0.0);
        int ratingCount = movie.getRatings().size();
        double popularityScore = avgRating * Math.log10(ratingCount + 1); // Logarithmic scaling

        // Recency score (newer movies get higher scores)
        int currentYear = java.time.Year.now().getValue();
        double recencyScore = Math.max(0, 1 - (double) (currentYear - movie.getReleaseYear()) / 20);

        // Diversity factor (to avoid recommending too many similar movies)
        double diversityFactor = calculateDiversityFactor(movie, alreadyRecommended);

        return (genreScore * 0.4) + (popularityScore * 0.3) + (recencyScore * 0.2) + (diversityFactor * 0.1);
    }
    
    private double calculateRecommendationScore(Movie movie, Map<Genre, Double> preferredGenres) {
        return calculateRecommendationScore(movie, preferredGenres, new ArrayList<>());
    }
    
    private double calculateDiversityFactor(Movie movie, List<Movie> alreadyRecommended) {
        if (alreadyRecommended.isEmpty()) {
            return 1.0; // Maximum diversity for first recommendation
        }
        
        // Calculate how similar this movie is to already recommended movies
        double similarityScore = 0.0;
        for (Movie recommended : alreadyRecommended) {
            // Calculate genre overlap
            Set<Genre> movieGenres = new HashSet<>(movie.getGenres());
            Set<Genre> recommendedGenres = new HashSet<>(recommended.getGenres());
            
            // Find intersection
            movieGenres.retainAll(recommendedGenres);
            
            // Calculate similarity based on genre overlap
            double genreSimilarity = (double) movieGenres.size() / 
                Math.max(movie.getGenres().size(), recommended.getGenres().size());
            
            similarityScore += genreSimilarity;
        }
        
        // Average similarity
        double avgSimilarity = similarityScore / alreadyRecommended.size();
        
        // Return diversity (1 - similarity)
        return 1.0 - avgSimilarity;
    }
}
