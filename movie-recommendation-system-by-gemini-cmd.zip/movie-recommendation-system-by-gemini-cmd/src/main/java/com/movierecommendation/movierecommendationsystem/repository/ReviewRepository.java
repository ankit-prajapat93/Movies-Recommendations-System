package com.movierecommendation.movierecommendationsystem.repository;

import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.model.Review;
import com.movierecommendation.movierecommendationsystem.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByMovie(Movie movie);
    List<Review> findByUser(User user);
    Optional<Review> findByUserAndMovie(User user, Movie movie);
}
