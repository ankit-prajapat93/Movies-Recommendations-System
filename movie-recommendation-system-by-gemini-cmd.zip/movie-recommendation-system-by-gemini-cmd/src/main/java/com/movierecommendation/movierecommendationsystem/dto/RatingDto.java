package com.movierecommendation.movierecommendationsystem.dto;

import com.movierecommendation.movierecommendationsystem.model.Rating;

public class RatingDto {
    private Long id;
    private Integer rating;
    private Long userId;
    private String username;
    private Long movieId;
    private String movieTitle;

    public RatingDto(Rating rating) {
        this.id = rating.getId();
        this.rating = rating.getRating();
        this.userId = rating.getUser().getId();
        this.username = rating.getUser().getUsername();
        this.movieId = rating.getMovie().getId();
        this.movieTitle = rating.getMovie().getTitle();
    }

    // Getters
    public Long getId() {
        return id;
    }

    public Integer getRating() {
        return rating;
    }

    public Long getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public Long getMovieId() {
        return movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }
}
