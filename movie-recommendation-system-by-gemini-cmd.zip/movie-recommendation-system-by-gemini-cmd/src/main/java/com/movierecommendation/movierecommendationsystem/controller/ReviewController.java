package com.movierecommendation.movierecommendationsystem.controller;

import com.movierecommendation.movierecommendationsystem.dto.ApiResponse;
import com.movierecommendation.movierecommendationsystem.dto.ReviewDto;
import com.movierecommendation.movierecommendationsystem.dto.ReviewRequest;
import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.model.Review;
import com.movierecommendation.movierecommendationsystem.model.User;
import com.movierecommendation.movierecommendationsystem.repository.MovieRepository;
import com.movierecommendation.movierecommendationsystem.repository.ReviewRepository;
import com.movierecommendation.movierecommendationsystem.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final MovieRepository movieRepository;

    public ReviewController(ReviewRepository reviewRepository, UserRepository userRepository, MovieRepository movieRepository) {
        this.reviewRepository = reviewRepository;
        this.userRepository = userRepository;
        this.movieRepository = movieRepository;
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
    }

    @PostMapping("/movies/{movieId}")
    public ResponseEntity<?> addOrUpdateReview(@PathVariable Long movieId, @Valid @RequestBody ReviewRequest reviewRequest) {
        User currentUser = getCurrentUser();
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new RuntimeException("Movie not found with id: " + movieId));

        Optional<Review> existingReview = reviewRepository.findByUserAndMovie(currentUser, movie);

        Review review;
        if (existingReview.isPresent()) {
            review = existingReview.get();
            review.setReviewText(reviewRequest.getReviewText());
            reviewRepository.save(review);
            return new ResponseEntity<>(new ApiResponse(true, "Review updated successfully", new ReviewDto(review)), HttpStatus.OK);
        } else {
            review = new Review(reviewRequest.getReviewText(), currentUser, movie);
            reviewRepository.save(review);
            return new ResponseEntity<>(new ApiResponse(true, "Review added successfully", new ReviewDto(review)), HttpStatus.CREATED);
        }
    }

    @GetMapping("/movies/{movieId}")
    public ResponseEntity<List<ReviewDto>> getReviewsForMovie(@PathVariable Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new RuntimeException("Movie not found with id: " + movieId));

        List<ReviewDto> reviews = reviewRepository.findByMovie(movie).stream()
                .map(ReviewDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/my-reviews")
    public ResponseEntity<List<ReviewDto>> getMyReviews() {
        User currentUser = getCurrentUser();
        List<ReviewDto> reviews = reviewRepository.findByUser(currentUser).stream()
                .map(ReviewDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(reviews);
    }
}
