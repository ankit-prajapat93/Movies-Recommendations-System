package com.movierecommendation.movierecommendationsystem.dto;

import java.util.Set;
import java.util.stream.Collectors;

import com.movierecommendation.movierecommendationsystem.model.Genre;
import com.movierecommendation.movierecommendationsystem.model.Movie;

public class MovieDto {
    private Long id;
    private String title;
    private String synopsis;
    private Integer releaseYear;
    private String posterUrl;
    private String trailerUrl;
    private Set<String> genres; // Display genre names

    public MovieDto(Movie movie) {
        this.id = movie.getId();
        this.title = movie.getTitle();
        this.synopsis = movie.getSynopsis();
        this.releaseYear = movie.getReleaseYear();
        this.posterUrl = movie.getPosterUrl();
        this.trailerUrl = movie.getTrailerUrl();
        this.genres = movie.getGenres().stream()
                            .map(Genre::getName)
                            .collect(Collectors.toSet());
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public Integer getReleaseYear() {
        return releaseYear;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public String getTrailerUrl() {
        return trailerUrl;
    }

    public Set<String> getGenres() {
        return genres;
    }
}
