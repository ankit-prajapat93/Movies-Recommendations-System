package com.movierecommendation.movierecommendationsystem.controller;

import com.movierecommendation.movierecommendationsystem.dto.ApiResponse;
import com.movierecommendation.movierecommendationsystem.dto.RatingDto;
import com.movierecommendation.movierecommendationsystem.dto.RatingRequest;
import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.model.Rating;
import com.movierecommendation.movierecommendationsystem.model.User;
import com.movierecommendation.movierecommendationsystem.repository.MovieRepository;
import com.movierecommendation.movierecommendationsystem.repository.RatingRepository;
import com.movierecommendation.movierecommendationsystem.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/ratings")
public class RatingController {

    private final RatingRepository ratingRepository;
    private final UserRepository userRepository;
    private final MovieRepository movieRepository;

    public RatingController(RatingRepository ratingRepository, UserRepository userRepository, MovieRepository movieRepository) {
        this.ratingRepository = ratingRepository;
        this.userRepository = userRepository;
        this.movieRepository = movieRepository;
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
    }

    @PostMapping("/movies/{movieId}")
    public ResponseEntity<?> addOrUpdateRating(@PathVariable Long movieId, @Valid @RequestBody RatingRequest ratingRequest) {
        User currentUser = getCurrentUser();
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new RuntimeException("Movie not found with id: " + movieId));

        Optional<Rating> existingRating = ratingRepository.findByUserAndMovie(currentUser, movie);

        Rating rating;
        if (existingRating.isPresent()) {
            rating = existingRating.get();
            rating.setRating(ratingRequest.getRating());
            ratingRepository.save(rating);
            return new ResponseEntity<>(new ApiResponse(true, "Rating updated successfully", new RatingDto(rating)), HttpStatus.OK);
        } else {
            rating = new Rating(ratingRequest.getRating(), currentUser, movie);
            ratingRepository.save(rating);
            return new ResponseEntity<>(new ApiResponse(true, "Rating added successfully", new RatingDto(rating)), HttpStatus.CREATED);
        }
    }

    @GetMapping("/movies/{movieId}")
    public ResponseEntity<List<RatingDto>> getRatingsForMovie(@PathVariable Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new RuntimeException("Movie not found with id: " + movieId));

        List<RatingDto> ratings = ratingRepository.findByMovie(movie).stream()
                .map(RatingDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ratings);
    }

    @GetMapping("/my-ratings")
    public ResponseEntity<List<RatingDto>> getMyRatings() {
        User currentUser = getCurrentUser();
        List<RatingDto> ratings = ratingRepository.findByUser(currentUser).stream()
                .map(RatingDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ratings);
    }
}
