package com.movierecommendation.movierecommendationsystem.controller;

import com.movierecommendation.movierecommendationsystem.dto.MovieCreateUpdateDto;
import com.movierecommendation.movierecommendationsystem.dto.MovieDto;
import com.movierecommendation.movierecommendationsystem.model.Genre;
import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.repository.GenreRepository;
import com.movierecommendation.movierecommendationsystem.repository.MovieRepository;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/movies")
public class MovieController {

    private final MovieRepository movieRepository;
    private final GenreRepository genreRepository;

    public MovieController(MovieRepository movieRepository, GenreRepository genreRepository) {
        this.movieRepository = movieRepository;
        this.genreRepository = genreRepository;
    }

    @GetMapping
    public ResponseEntity<List<MovieDto>> getAllMovies() {
        List<MovieDto> movies = movieRepository.findAll()
                .stream()
                .map(MovieDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(movies);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MovieDto> getMovieById(@PathVariable Long id) {
        return movieRepository.findById(id)
                .map(MovieDto::new)
                .map(ResponseEntity::ok)
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/search")
    public ResponseEntity<List<MovieDto>> searchMovies(@RequestParam String query) {
        List<MovieDto> movies = movieRepository.findByTitleContainingIgnoreCase(query)
                .stream()
                .map(MovieDto::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(movies);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<MovieDto> createMovie(@Valid @RequestBody MovieCreateUpdateDto movieCreateUpdateDto) {
        Movie movie = new Movie();
        movie.setTitle(movieCreateUpdateDto.getTitle());
        movie.setSynopsis(movieCreateUpdateDto.getSynopsis());
        movie.setReleaseYear(movieCreateUpdateDto.getReleaseYear());
        movie.setPosterUrl(movieCreateUpdateDto.getPosterUrl());
        movie.setTrailerUrl(movieCreateUpdateDto.getTrailerUrl());

        if (movieCreateUpdateDto.getGenreNames() != null && !movieCreateUpdateDto.getGenreNames().isEmpty()) {
            Set<Genre> genres = new HashSet<>();
            for (String genreName : movieCreateUpdateDto.getGenreNames()) {
                genreRepository.findByName(genreName)
                        .ifPresentOrElse(
                                genres::add,
                                () -> {
                                    Genre newGenre = new Genre(genreName);
                                    genreRepository.save(newGenre);
                                    genres.add(newGenre);
                                }
                        );
            }
            movie.setGenres(genres);
        }

        Movie savedMovie = movieRepository.save(movie);
        return new ResponseEntity<>(new MovieDto(savedMovie), HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<MovieDto> updateMovie(@PathVariable Long id, @Valid @RequestBody MovieCreateUpdateDto movieCreateUpdateDto) {
        return movieRepository.findById(id)
                .map(movie -> {
                    movie.setTitle(movieCreateUpdateDto.getTitle());
                    movie.setSynopsis(movieCreateUpdateDto.getSynopsis());
                    movie.setReleaseYear(movieCreateUpdateDto.getReleaseYear());
                    movie.setPosterUrl(movieCreateUpdateDto.getPosterUrl());
                    movie.setTrailerUrl(movieCreateUpdateDto.getTrailerUrl());

                    if (movieCreateUpdateDto.getGenreNames() != null) {
                        Set<Genre> genres = new HashSet<>();
                        for (String genreName : movieCreateUpdateDto.getGenreNames()) {
                            genreRepository.findByName(genreName)
                                    .ifPresentOrElse(
                                            genres::add,
                                            () -> {
                                                Genre newGenre = new Genre(genreName);
                                                genreRepository.save(newGenre);
                                                genres.add(newGenre);
                                            }
                                    );
                        }
                        movie.setGenres(genres);
                    } else {
                        movie.setGenres(new HashSet<>()); // Clear genres if none provided
                    }

                    Movie updatedMovie = movieRepository.save(movie);
                    return new ResponseEntity<>(new MovieDto(updatedMovie), HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable Long id) {
        if (movieRepository.existsById(id)) {
            movieRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
