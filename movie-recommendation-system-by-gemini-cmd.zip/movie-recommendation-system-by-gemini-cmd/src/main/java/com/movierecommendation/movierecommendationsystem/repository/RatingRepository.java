package com.movierecommendation.movierecommendationsystem.repository;

import com.movierecommendation.movierecommendationsystem.model.Movie;
import com.movierecommendation.movierecommendationsystem.model.Rating;
import com.movierecommendation.movierecommendationsystem.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface RatingRepository extends JpaRepository<Rating, Long> {
    Optional<Rating> findByUserAndMovie(User user, Movie movie);
    List<Rating> findByUser(User user);
    List<Rating> findByMovie(Movie movie);
    List<Rating> findByUserAndRatingGreaterThanEqual(User user, Integer rating);
    
    @Query("SELECT r.movie.id FROM Rating r WHERE r.user = :user")
    List<Long> findMovieIdsByUser(@Param("user") User user);

    @Query("SELECT r.user FROM Rating r WHERE r.movie IN :movies AND r.user != :user AND r.rating >= 4")
    List<User> findSimilarUsers(@Param("user") User user, @Param("movies") Set<Movie> movies);

    @Query("SELECT r.movie.id FROM Rating r WHERE r.user IN :users AND r.rating >= 4 AND r.movie.id NOT IN :movieIds")
    Set<Long> findMoviesFromSimilarUsers(@Param("users") List<User> users, @Param("movieIds") Set<Long> movieIds);
}
