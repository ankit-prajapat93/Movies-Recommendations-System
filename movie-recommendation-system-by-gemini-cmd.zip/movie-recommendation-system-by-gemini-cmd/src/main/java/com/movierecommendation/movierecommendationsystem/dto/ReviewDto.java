package com.movierecommendation.movierecommendationsystem.dto;

import com.movierecommendation.movierecommendationsystem.model.Review;
import java.time.LocalDateTime;

public class ReviewDto {
    private Long id;
    private String reviewText;
    private Long userId;
    private String username;
    private Long movieId;
    private String movieTitle;
    private LocalDateTime createdAt;

    public ReviewDto(Review review) {
        this.id = review.getId();
        this.reviewText = review.getReviewText();
        this.userId = review.getUser().getId();
        this.username = review.getUser().getUsername();
        this.movieId = review.getMovie().getId();
        this.movieTitle = review.getMovie().getTitle();
        this.createdAt = review.getCreatedAt();
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getReviewText() {
        return reviewText;
    }

    public Long getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public Long getMovieId() {
        return movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
