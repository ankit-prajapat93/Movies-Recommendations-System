package com.movierecommendation.movierecommendationsystem.repository;

import com.movierecommendation.movierecommendationsystem.model.Genre;
import com.movierecommendation.movierecommendationsystem.model.Movie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
    List<Movie> findByTitleContainingIgnoreCase(String title);
    List<Movie> findByReleaseYear(Integer releaseYear);

    @Query("SELECT m FROM Movie m JOIN m.genres g WHERE g IN :genres AND m.id NOT IN :movieIds")
    List<Movie> findTop50ByGenresInAndIdNotIn(@Param("genres") Set<Genre> genres, @Param("movieIds") Set<Long> movieIds, Pageable pageable);

    @Query("SELECT m, AVG(r.rating) as avg_rating FROM Movie m LEFT JOIN m.ratings r WHERE m.id IN :movieIds GROUP BY m.id ORDER BY avg_rating DESC")
    List<Object[]> findMoviesWithAverageRating(@Param("movieIds") Set<Long> movieIds);

    @Query("SELECT m FROM Movie m LEFT JOIN FETCH m.ratings r GROUP BY m ORDER BY AVG(r.rating) DESC")
    Page<Movie> findTopRatedMovies(Pageable pageable);

    @Query("SELECT m FROM Movie m WHERE m.releaseYear >= :year ORDER BY m.releaseYear DESC")
    Page<Movie> findRecentMovies(@Param("year") int year, Pageable pageable);
    
    @Query("SELECT m FROM Movie m JOIN m.genres g WHERE g = :genre")
    Page<Movie> findByGenresContaining(@Param("genre") Genre genre, Pageable pageable);
}
