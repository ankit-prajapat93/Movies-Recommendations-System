import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordGenerator {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        
        String adminPassword = "admin123";
        String userPassword = "user123";
        
        String hashedAdmin = encoder.encode(adminPassword);
        String hashedUser = encoder.encode(userPassword);
        
        System.out.println("Admin password (" + adminPassword + "): " + hashedAdmin);
        System.out.println("User password (" + userPassword + "): " + hashedUser);
    }
}